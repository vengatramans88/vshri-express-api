const express = require("express");

const router = express.Router();

const userController = require("../controllers/userController");

const validateRequest = require("../middleware/validateRequest");

const { createUserValidation } = require("../validators/userValidator");

router.post(

    "/",

    createUserValidation,

    validateRequest,

    userController.createUser

);

module.exports = router;