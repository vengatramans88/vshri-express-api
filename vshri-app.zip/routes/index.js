const express = require("express");
const router = express.Router();

const userRoutes = require("./userRoutes");

router.get("/", (req, res) => {
    res.json({
        success: true,
        message: "Welcome to VSHRI Express API 🚀"
    });
});

router.get("/health", (req, res) => {
    res.json({
        success: true,
        status: "UP",
        uptime: process.uptime(),
        version: "1.0.0"

    });
});

router.use("/users", userRoutes);

module.exports = router;